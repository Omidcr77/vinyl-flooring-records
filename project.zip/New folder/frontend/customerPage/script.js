const socket = io("http://localhost:5000"); // Change to your backend URL

let customers = [];

// ✅ Listen for new customer added
socket.on("customerAdded", (newCustomer) => {
    customers.push(newCustomer);
    loadCustomers();
});

// ✅ Listen for customer balance updates
socket.on("balanceUpdated", (updatedCustomer) => {
    let index = customers.findIndex(c => c._id === updatedCustomer._id);
    if (index !== -1) {
        customers[index] = updatedCustomer;
        loadCustomers();
    }
});

// ✅ Listen for customer deletion
socket.on("customerDeleted", (customerId) => {
    customers = customers.filter(c => c._id !== customerId);
    loadCustomers();
});

// ✅ Variable to store selected customer
let selectedCustomerId = null;

// ✅ Function to delete a customer
async function deleteSelectedCustomer() {
    if (!selectedCustomerId) {
        alert("❌ لطفاً یک مشتری را انتخاب کنید.");
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/api/customers/${selectedCustomerId}`, {
            method: "DELETE"
        });

        if (!response.ok) throw new Error("❌ حذف مشتری انجام نشد.");

        // Emit deletion event
        socket.emit("deleteCustomer", selectedCustomerId);

        selectedCustomerId = null; // Reset selection
        loadCustomers();
        alert("✅ مشتری با موفقیت حذف شد!");

    } catch (error) {
        console.error("Error deleting customer:", error);
    }
}

// ✅ Function to update statistics
function updateStatistics() {
    let totalCustomers = customers.length;
    let totalBalance = customers.reduce((sum, customer) => sum + customer.balance, 0).toLocaleString();

    document.getElementById("totalCustomers").textContent = totalCustomers;
    document.getElementById("totalBalance").textContent = `${totalBalance} دالر`;
}

// ✅ Function to add a new customer
async function addCustomer() {
    let nameInput = document.getElementById("customerName");
    let phoneInput = document.getElementById("customerPhone");
    let addressInput = document.getElementById("customerAddress");
    let balanceInput = document.getElementById("customerBalance");
    let imgInput = document.getElementById("customerPic");

    if (!nameInput || !phoneInput || !addressInput || !balanceInput) {
        console.error("❌ One or more input fields are missing!");
        alert("⚠️ Please fill out all fields correctly.");
        return;
    }

    let newCustomer = {
        name: nameInput.value.trim(),
        phone: phoneInput.value.trim(),
        address: addressInput.value.trim(),
        balance: parseFloat(balanceInput.value) || 0, // Ensure valid balance
        img: imgInput ? imgInput.value.trim() : "assets/customer.jpg", // Default image if missing
        vinyls: [],
        receipts: []
    };

    try {
        const response = await fetch("http://localhost:5000/api/customers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newCustomer)
        });

        if (!response.ok) throw new Error("❌ Failed to add customer.");

        const savedCustomer = await response.json();

        // Emit event to backend
        socket.emit("newCustomer", savedCustomer);

        // Reload UI
        loadCustomers();
        closeModal("addCustomerModal");

        // Clear form fields
        nameInput.value = "";
        phoneInput.value = "";
        addressInput.value = "";
        balanceInput.value = "";

    } catch (error) {
        console.error("Error adding customer:", error);
    }
}


// ✅ Function to load customers into the UI
async function loadCustomers() {
    try {
        const response = await fetch("http://localhost:5000/api/customers");
        if (!response.ok) throw new Error("❌ دریافت لیست مشتریان انجام نشد.");

        customers = await response.json();

        let customerGrid = document.getElementById("customerGrid");
        customerGrid.innerHTML = "";

        customers.forEach(customer => {
            let card = document.createElement("div");
            card.className = "customer-card";
            card.setAttribute("data-id", customer._id);
            card.innerHTML = `
                <img src="${customer.img}" alt="${customer.name}">
                <h3>${customer.name}</h3>
                <p><strong>📞 شماره تلفون:</strong> ${customer.phone}</p>
                <p><strong>📍 آدرس:</strong> ${customer.address}</p>
                <p><strong>💰 حساب:</strong> ${customer.balance.toLocaleString()} دالر</p>
                <button class="select-btn" onclick="selectCustomer('${customer._id}')">✔️ انتخاب</button>
            `;

            card.addEventListener("click", () => {
                window.location.href = `customerDetails.html?id=${customer._id}`;
            });
            

            customerGrid.appendChild(card);
        });

        updateStatistics();
    } catch (error) {
        console.error("Error loading customers:", error);
    }
}

// ✅ Function to select a customer
function selectCustomer(customerId) {
    selectedCustomerId = customerId;
    alert("✅ مشتری انتخاب شد. حالا می‌توانید آن را حذف کنید.");
}

// ✅ Function to open a modal
function openModal(modalId) {
    let modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = "flex"; // Show modal before animation
        setTimeout(() => {
            modal.classList.add("visible");
        }, 10);
    }
}

// ✅ Function to close a modal
function closeModal(modalId) {
    let modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove("visible");
        setTimeout(() => {
            modal.style.display = "none"; // Ensure it's hidden after animation
        }, 300);
    }
}

// ✅ Close modal when clicking outside
window.onclick = function(event) {
    let modals = document.querySelectorAll(".modal");
    modals.forEach(modal => {
        if (event.target === modal) {
            closeModal(modal.id);
        }
    });
};

// ✅ Close modal when pressing ESC key
document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        let modals = document.querySelectorAll(".modal");
        modals.forEach(modal => {
            if (modal.classList.contains("visible")) {
                closeModal(modal.id);
            }
        });
    }
});

// ✅ Search Customers
function searchCustomer() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let customerCards = document.querySelectorAll(".customer-card");

    customerCards.forEach(card => {
        let name = card.querySelector("h3").innerText.toLowerCase();
        card.style.display = name.includes(input) ? "block" : "none";
    });
}

// ✅ Load customers when the page loads
document.addEventListener("DOMContentLoaded", loadCustomers);
